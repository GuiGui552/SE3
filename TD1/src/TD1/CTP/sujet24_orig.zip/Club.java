class Club {
    static final int nbMatchs=19;
    
    int res;
    int[] points=new int[nbMatchs]; // points obtenus pour chacun des matchs
    int id; // identifiant du club
}
